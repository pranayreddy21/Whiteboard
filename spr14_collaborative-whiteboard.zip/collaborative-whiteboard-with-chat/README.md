# collaborative-whiteboard-with-chat  

HOW TO RUN
----------

1. `git clone https://github.com/rupinder1133/collaborative-whiteboard-with-chat.git`
2.  `cd collaborative-whiteboard-with-chat`
3.  `npm install`
4.  `npm start`
5.  Open `localhost:3000` in Browser

![alt text](https://github.com/rupinder1133/collaborative-whiteboard-with-chat/blob/master/Demo.gif "Demo")
